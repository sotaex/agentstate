# AUDIT_SCHEMA.md — Antinel 审计记录模式 v1.6（随 v0.29.0）

> 本文是 `.psl/audit/` 下每一条记录的**字段级契约**，供第三方独立复核。
> 原则：**记录里只有事实与指纹，没有内容、没有评分**。任何字段语义变更必须 bump 本文档版本并在变更说明中登记。
> v1.1（0.23.0）：新增 `usage_delta` 记录类型（token 事实）；`session_dna` 新增 `usage` 块（聚合与**派生**成本估算）。
> v1.2（0.28.0）：**降级记录迁移至 sidecar**——`chain:"unlocked"` 的记录不再写入主链，改写 `audit/sidecar/<日>.<pid>.jsonl`（单写者文件）；主链从此只含按锁定协议成链的记录。依据：《v0.28 条款·链并发语义 v2》C-2/C-3（葛广 2026-09-21 确认）；动机：Gauntlet 实证 unlocked 直写主链与持锁写相撞会产生与篡改同形的分叉。
> v1.3（0.28.0）：**补登记门闸事件族**（`host_shield_*` 共 6 类，见 §4 门闸类）。此前代码已写入**同一条链**而本文未登记 —— §4 自称"枚举"，缺登记即契约不成立。依据：《Antinel 门闸自检两处缺口取证（fail-open ＋ 未登记事件）（2026-09-24）》F2。
> v1.4（0.28.1）：门闸事件族新增 `host_shield_revived`（哨兵死亡后被 paramedic/CLI 重新拉起）与 `host_shield_spawn_failed`（拉起失败＝门闸无人值守的显式证据）；`host_shield_changed` 增补 `autostart`（schtasks / startup-folder / none）与 `spawn`（ok / failed）两个字段。依据：同日《哨兵死因取证》（重建丢 `__main__` 入口、schtasks rc 未查、会话 Job 连带杀、`-I` 下留痕全聋）。
> v1.5（0.28.3）：门闸事件族新增 `host_shield_tamper`（状态文件/登记表/自身代码与审计链或 manifest 不符——B4b/b2/c/d、B4e/f 类"无声开关"的显式证据）；`host_shield_changed` 增补 `armed` 布尔字段（enabled 翻转后的权威值，哨兵据此链权威执法）；`host_shield_breach` 的语义从三种扩为四种（新增④心跳陈旧且旧进程镜像异常，拒绝自动重启）。依据：同日《哨兵绕过办法全谱与根方案对照 v1.0》。
> v1.6（0.29.0）：**补登记 6 个早已写入同一条链、但本文从未登记的事件类型** —— `dst11_syncdir_released`（新增）、`rules_integrity_fallback`、`rules_unreadable_fallback`、`policy_changed`、`credits_snapshot`、`digest_rollup`。同时把抬头版本从 v1.3 修正到 v1.6（抬头落后两版：v1.4/v1.5 的变更说明已写在正文，标题却一直没改）。
> v1.6a（0.29.0，同日）：**门闸族再补登记 2 类** —— `host_shield_lock_held`、`host_shield_contested`（见 §4）。这两类是 v1.3 补登记门闸族时**漏掉的**：v1.3 的变更说明自称"共 6 类"，而代码里实际有 13 类，两处一直没有对齐。**发现方式＝同一道 INV-6**（严格测试的 257 条断言里，`F-10 门闸事件类型全部登记于 AUDIT_SCHEMA.md（11 类）` 报 `未登记: ['host_shield_contested', 'host_shield_lock_held']`）。
> ★ **教训（第三次同一类）**："补登记"如果只按**手写清单**补，就会漏；只有**扫代码写出的 type**才对得上。v1.3 是手写清单补的，所以漏了 2 个；v1.6 的另外 6 个是 INV-6 扫出来的，所以齐了。**没对象的检查项＝假守卫；有对象的检查项才补得齐。**
> **依据（本条的来源就是一次自查）**：`antinel_verify.py --invariants` 的 INV-6 用正则扫出"代码写入的 type ∉ 本文登记"，一次跑出 7 个未登记项。**这正是本项目的契约纪律：「没登记 ≠ 不存在」**——链上写着一个类型，而随包契约里没有它，第三方复核时就无从知道那个字段是什么意思。**现在 INV-6 是一道会红的守卫**，不是一句口号。

## 1. 存放位置

| 位置 | 内容 |
|---|---|
| `<root>/.psl/audit/YYYY-MM-DD.jsonl` | 当日审计链（每行一条 JSON 记录，**仅含按锁定协议成链的记录**） |
| `<root>/.psl/audit/day_manifest.json` | 日锚：每日文件的字节大小 + 末行 hash（链外副本，用于检出尾部删除） |
| `<root>/.psl/audit/sidecar/YYYY-MM-DD.<pid>.jsonl` | **v1.2**：锁竞争超时的降级记录（自带 `chain:"unlocked"` 标记；单写者文件；经 `--fold-sidecars` 显式并链后改名留档） |
| `<root>/.psl/audit/YYYY-MM-DD.jsonl.gz` | 过期归档（`report.py --archive`，默认 30 天） |
| 宿主镜像目录（如 `~/.workbuddy/antinel-audit/`） | 关键 allow 事件的宿主级副本（项目目录被删时证据仍在） |

## 2. 链字段（每条链上记录必备）

| 字段 | 含义 |
|---|---|
| `prev` | 前一条记录 hash 的**末 16 位**（首条为 ""） |
| `hash` | `sha256(prev + canonical_json(record 去掉 hash 字段))`，canonical = `sort_keys=True, separators=(",", ":")` |
| `chain` | 仅在降级时出现：`"unlocked"` = 锁竞争超时写入（**v1.2 起该记录落 sidecar，不进主链**；并链时重算 prev/hash，原记录体不变） |

**例外（历史遗留）**：`session_start` 心跳记录目前为**无链直写**（见 §4）。无 `hash` 的记录不参与链校验，也不破坏链（verify_chain 跳过无 hash 行）。

**锁协议**（v1.2 起为锁文件内容契约 `{pid, ts, token}`，偷锁前存活探测、释放前 token 匹配）属实现语义，见《Antinel v0.28 条款·链并发语义 v2》；本模式只约束其在记录上的可见后果。

**复核入口**：`tools/verify_chain.py <audit_dir>`（逐条链校验 + 日锚对照，`--json` 机器可读，`--all` 含历史日）。任何第三方拿到审计目录即可复算全部 hash。

## 3. 公共字段

| 字段 | 出现于 | 含义 |
|---|---|---|
| `ts` | 全部 | 本地时间 ISO8601（秒精度） |
| `type` | 全部 | 记录类型（§4 枚举） |
| `tool` | 多数 | 工具名（pre 侧为宿主原名；规则匹配用 canonical 名：MultiEdit→Edit、NotebookEdit→Write、ApplyPatch→Edit、Task→Agent） |
| `session` | 多数 | 宿主会话 id；`"banner"`=心跳伪会话 |
| `host` | 多数 | 宿主标签（claude-code / zcode / workbuddy / generic …） |
| `input.command` | pre/post | 命令文本，**经 mask_secrets 脱敏、截断至 500 字符** |
| `input.file_path` | pre/post | 目标路径（脱敏后原文保留） |
| `input.content_len` | pre | 内容长度（只记长度，不记内容） |
| `content_digest` | pre/post | `sha256(canonical_json({tool_name, tool_input}))` — **pre↔post 配对键**（两侧同配方，spec 2.8） |

## 4. 记录类型枚举

### 决策类

| type | 来源 | 关键字段 | 说明 |
|---|---|---|---|
| `pre_tool_use` | pre | `rules_hit[]`, `severity`, `action(block/alert/allow)`, `decision`, `file_state_before`, `released[]` | 每次调用一条；**`released[]` 为 0.29.0 (D-1) 新增**：本次调用中**命中了但被 `whitelist.paths` 放行**的规则 id 列表（无放行时该字段不存在）。★ 有它，`rules_hit=[]` 才有唯一解释（真的没命中），而不是被"放行"冒名顶替；`file_state_before` 为 **0.22.0 (C1)** 新增：写工具（Write/Edit）目标文件的写前状态 `{hash, size}` / `{hash:"absent"}` / `{hash:"too_large",size}` / `{hash:"unreadable"}`（>1MB 只记尺寸；被拦截的尝试同样记录——"对什么状态发起过写入"本身就是证据） |
| `pre_tool_use_summary` | pre | `rules_hit`, `decision` | 决策摘要行（各决策记录之外的一条汇总） |
| `post_tool_use` | post | `response_digest`, `response_chars`, `rules_hit`(OUT-01), `sensitive_output[]`, `canaries_observed[]`, `exit_code`, `file_state_after` | `exit_code` 为 **0.22.0 (B1)**：宿主暴露的数字退出码，取不到为 `null`（**缺失不造假**）；`file_state_after` 为 **0.22.0 (C1)**：写后状态，与 `file_state_before` 经 `content_digest` 配对。**时长 = post.ts − pre.ts，由 report 层派生，钩子不记** |

### 会话与心跳

| type | 来源 | 关键字段 | 说明 |
|---|---|---|---|
| `session_start` | banner | `reason` | SessionStart 心跳（**无链直写，历史遗留**） |
| `hook_alive` | pre | — | 当日首次调用的心跳 |
| `session_dna` | report / banner | 见 §5 | **0.22.0 (A5)**：会话汇总，链上记录 |

### 释放留痕类（"放行必须留痕"）

| type | 来源 | 说明 |
|---|---|---|
| `workspace_root_allow` | pre | 因 `workspace_roots` 而放行的本应拦截项（记 `matched_root`、`config_source`） |
| `exclude_patterns_allow` | pre | 因规则 `exclude_patterns` 放行的 critical 命中（宿主级镜像） |
| `dst02_path_whitelisted` | pre | 因 `whitelist.paths` 放行的 DST-02 |
| `dst02_host_config_self_maintenance` | pre | Antinel 自身宿主级配置的自我维护写入 |
| `dst02_bash_path_suspect` | pre | Bash 命令文本中出现根外绝对路径（**提醒不拦截**） |
| `dst11_syncdir_released` | pre | **0.29.0 (G-8)**：写进云盘同步目录、被 `whitelist.paths` 放行。单独命名（不并入 `dst02_path_whitelisted`），因为"放行了一次写进同步文件夹"与"放行了一次写项目外"是两件不同的事——同步客户端**仍然会把文件传上云**。记 `input.file_path` |
| `workspace_config_rejected` | pre | 被拒绝的 workspace_roots 配置（含拒绝原因） |
| `sec_path_whitelisted` | pre | **0.29.0 (D-1)**：命中了 secrets 规则（读 .env / SSH 私钥 / 云凭证 / 微信本地库 …）但被 `whitelist.paths` 放行。单独命名（不并入 `dst02_path_whitelisted`），因为"放行一次读敏感文件"与"放行一次写项目外"是两件不同的事。记 `rule_id`、`input.file_path`、`input.command`。★ **这是全仓最后一个静默放行通道**：在此之前该放行**不写任何记录**，于是账本上它与"压根没命中任何规则"逐字段相同（`rules_hit=[]`、`severity="none"`），事后复盘无从区分——**判据④「'没查'被伪装成'没发现'」的同型：此处是「被放行」被伪装成「没命中」** |

### 降级与配置变更类（v1.6 补登记）

> ★ 本组此前**代码已在写、本文未登记**（v1.6 补）。补登记的依据是"没登记 ≠ 不存在"：
> 链上有这个类型，随包契约里就必须有它的字段语义，否则第三方复核无从下手。

| type | 来源 | 关键字段 | 说明 |
|---|---|---|---|
| `rules_integrity_fallback` | pre | `expected`, `live`, `rules_loaded` | `rules/default.json` 与 manifest 的 `rules_hash` 不符 ⇒ 判定为篡改，**退回内置兜底规则集**并大声记账（A4）。`expected`/`live` 是两侧哈希，供复核 |
| `rules_unreadable_fallback` | pre | `error`, `rules_loaded` | 规则文件**读不出来**（缺失/坏 JSON/无权限）⇒ 退回内置兜底集。与上一条**分开命名**：`tampered` 与 `unreadable` 是两种不同的失败，不能合并成一条 |
| `policy_changed` | antinel CLI | `change` | `.psl/policy.json` 被 CLI 改写（白名单/阈值/档位）。每一次都记，因为**放行范围因此改变** |
| `credits_snapshot` | antinel CLI | 余额快照 | 用户登记的积分余额事实（`antinel credits snapshot`）。**是事实记录，不是估算** |
| `digest_rollup` | antinel CLI | 汇总 | 日报/汇总层生成的滚存记录 |

### 资源账本类（0.23.0）

| type | 来源 | 关键字段 | 说明 |
|---|---|---|---|
| `usage_delta` | post | `source{path_tag, scope, reset, bytes_read, deduped, usage_source}`, `entries[]` | **token 事实**。每次从 transcript 增量收割到新条目时追加一条（收割不到就不写，不写空记录）。`entries[]` 元素：`{ts, model, input_tokens, output_tokens, cache_read_input_tokens, cache_creation_input_tokens, total_tokens, id}`——全部为宿主 transcript 中的原始数值（缺字段为 null，不补 0、不推算）。`path_tag` = transcript 路径的 sha256 前 16 位（**路径原文不进账本**，只存在本地 `.psl/state/usage_offsets.json`）；`scope` = incremental / tail_first_sight；`reset`=true 表示 transcript 文件变小后重读（重叠条目按指纹去重，`deduped` 计数）。**成本永不写入此记录**——token 是事实，成本是派生物 |

### 错误类

| type | 来源 | 说明 |
|---|---|---|
| `hook_error` | pre | 钩子内部异常（fail-open，宿主不受影响） |

### 门闸类（host-shield，v1.3 补登记；v1.4 增补）

> 由 `host_shield.py` 哨兵与 `antinel.py host-shield enable/disable` 写入**与上表同一条链**。
> ★ 门闸**默认关闭**（须 `antinel host-shield enable` 才布防）；未布防时链中不出现本族记录。
> 本族 `session` 固定为 `"host-shield"`、`tool` 固定为 `"-"`、`host` 固定为 `"generic"`（见 §3 公共字段）。

| type | 来源 | 关键字段 | 说明 |
|---|---|---|---|
| `host_shield_zone_locked` | 哨兵 | `decision="deny"`, `reason`(含路径) | 安全区（zone）已上锁：区内防篡改；出网另由 `net_mode` 把闸 |
| `host_shield_breach` | 哨兵 | `decision="deny"` | **门闸异常**四种：① 自启缺失（计划任务与启动文件夹均无，`#6`）② 发现未拦的外传落盘点并补锁（补锁失败时 severity=critical）③ 发现符号链接（绕过载体）④ 心跳陈旧（疑似挂起/僵死）且旧进程镜像异常，拒绝自动重启 |
| `host_shield_task_unknown` | 哨兵 | `decision="alert"` | **v1.3 新增**：无法确认计划任务状态（`schtasks` 不可用／被策略拦截／超时）。★ 与 `breach` **分开记** —— **"查不出来"不是"查到了是坏的"**；此前该情形被 fail-open 吞成"已安装"，导致 `breach` 永不触发 |
| `host_shield_window_closed` | 哨兵 | `decision`, `reason` | 放行窗到期关闭 |
| `host_shield_heartbeat` | 哨兵 | `decision="allow"`, `watched`(登记路径数) | 哨兵心跳（门闸在岗），每 `HEARTBEAT_SECONDS` 一次；**断档由晨报/`host-shield status` 呈现**（v1.4 起） |
| `host_shield_changed` | `antinel.py` | `decision="allow"`, `severity="warning"`, `field`, `change`, `invoked_by`, `autostart`, `spawn`, `armed` | 门闸被 enable／disable；`change` 为 `"false → true"` 形式。**v1.4 增补**：`autostart` ∈ schtasks / startup-folder / none（自启注册的真实结局，不假成功）；`spawn` ∈ ok / failed（哨兵本次是否真的拉起来了）。**v1.5 增补**：`armed` 布尔＝翻转后的权威值——哨兵对 enabled 的执法以链上本字段为准（B4b 系"无声开关"的闭合） |
| `host_shield_revived` | 哨兵/paramedic | `decision="allow"`, `pid`, `cause`, `spawn_mode` | **v1.4 新增**：哨兵死亡后被重新拉起（钩子 paramedic 或 CLI）。复活记录本身就是"此前有断档"的证据 |
| `host_shield_spawn_failed` | 哨兵/paramedic | `decision="deny"`, `severity="critical"`, `cause` | **v1.4 新增**：哨兵死亡且拉起失败——门闸无人值守的显式记录（此前该状态只存在于沉默里） |
| `host_shield_tamper` | 哨兵 | `decision="deny"`, `severity="critical"`, `field`, `reason` | **v1.5 新增**：本地配置与权威依据不符——state 文件 `enabled` 与链不一致（B4b/b2/c/d）；workspaces/zones/windows 无链背书被改并已回写恢复；启动自检发现运行代码/登记表与 manifest 不符（B4e/f）。执法按链/按已知值继续，绝不因文件被改而静默停摆 |
| `host_shield_lock_held` | 哨兵 | `decision="deny"`, `severity="none"`, `reason`(含路径) | **v1.6a 补登记**：门闸**持锁中**的周期性状态留痕（每 `LOCK_HELD_EVERY` 一次，`lock_held_at` 去重）。★ 与 `breach` **分开**：锁**在**是正常态，不该只在"出事"时才出现在账本上 —— 旧机制下 `if is_denied(...)` 为真就**整支跳过**，于是"锁挂了两个月、账本一字不提"（09-25/26 审计只剩心跳、零 breach） |
| `host_shield_contested` | 哨兵 | `decision="deny"`, `severity="critical"`, `reason`(含路径与补锁次数) | **v1.6a 补登记**：同一落点在 `CONTEST_WINDOW` 内被补锁 ≥ `CONTEST_TIMES` 次 —— 上锁**未稳定生效**或**有进程在对抗门闸**，须人工介入。★ 与 `breach` 的分工：`breach` 是"发现未拦的落点"（第 1 次，且明说"不等于有进程在对抗"），本类是"补锁反复不生效"（第 N 次） |

**本族不记什么**（与 §6 同源）：不读密文内容（红线 A3）；不记被拦文件的字节；`reason` 中的路径为脱敏后原文。

## 5. `session_dna` 字段表（0.22.0）

| 字段 | 含义 |
|---|---|
| `session`, `generated_at`, `generated_by` | 会话 id；生成时间；`report.py` 或 `session_start_rollup` |
| `coverage` | `{days:[日文件名], records:N, truncated:bool}`（banner 补算只扫最近 2 日 / 64MB） |
| `span` | `{first, last}` 该会话首末记录 ts |
| `actions` | `{total, by_tool{}}` — pre_tool_use 计数 |
| `blocks` | `{total, by_rule{}}` — 拦截计数与规则分布 |
| `warnings` | `{total}` — alert 计数 |
| `files` | `{touched_unique, top:[{path,count}×5]}` — 去重触碰文件与 Top5 |
| `durations` | `{pairs, median_ms, p95_ms}` — **content_digest 配对**的 pre/post 时长（同调用、pre≤post、<1h；重试按序配对） |
| `exits` | `{observed, nonzero}` — 有退出码的 post 记录数 / 其中非零数（null 不计入 observed） |
| `usage` | **0.23.0**：`{entries, by_model{model:{entries,input,output,cache_read,cache_creation,total}}}` — usage_delta 的聚合（**事实**） |
| `usage.cost_estimate` | **0.23.0**：`{currency, total, by_model{}, pricing_version, unpriced_models[]}` — **派生物**，仅当调用方提供 pricing 表时出现；rates 缺失的模型进 `unpriced_models`，**永不代估**。`pricing_version` 回指 `rules/pricing.json` 的 version |

生成原则：**DNA 只聚合链上已有记录，不推断、不评分**；成本只按调用方提供的定价表派生并永远标 estimate；`report.py --session <id> [--write-dna]`，补算写入走与全部记录相同的链配方（verify_chain 全覆盖）。

## 6. 隐私与边界（本模式"不记什么"）

- 不记文件内容、不记 diff——只有 sha256 与字节数（C1 亦然）。
- 命令文本脱敏（密钥/token 掩码）后截断 500 字符。
- 不记网络出站字节（钩子看不见；DST-02 类同，见 THREAT_MODEL Non-goals）。
- 成本/token 消耗（三问三答 A 族）**尚未进入账本**——`transcript_path` 已随事件到达但 v0.22.0 未使用，属 v0.23.0 范围。
